package com.accenture.lkm.exception;

public class MaxAllowedEntriesReachedException  extends Exception {
	public MaxAllowedEntriesReachedException(){
		super("Max Allowed Entries Reached Exception");
	}
	}
	
