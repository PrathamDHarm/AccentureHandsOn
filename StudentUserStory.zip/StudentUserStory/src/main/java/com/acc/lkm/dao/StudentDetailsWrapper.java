package com.acc.lkm.dao;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.acc.lkm.bean.StudentDetailsBean;
import com.acc.lkm.entity.StudentDetailsEntity;
import com.fasterxml.jackson.databind.util.BeanUtil;

@Repository
public class StudentDetailsWrapper {

	@Autowired
	public StudentDetailsDAO studentDetailsDAO;

	public Integer addDetails(StudentDetailsBean bean) throws Exception {
		Integer id = 0;
		try {
			StudentDetailsEntity entity = convertBeanToEntity(bean);
			StudentDetailsEntity e = studentDetailsDAO.save(entity);
			id = e.getId();
			System.out.println("Branch: "+e.getBranch());
		} catch (Exception e) {
			System.out.println("add details exception ");
		}
		return id;
	}

	private StudentDetailsEntity convertBeanToEntity(StudentDetailsBean bean) {
		// TODO Auto-generated method stub
		StudentDetailsEntity entity = new StudentDetailsEntity();
		BeanUtils.copyProperties(bean, entity);
		return entity;
	}

	private StudentDetailsBean convertEntityToBean(StudentDetailsEntity entity) {
		// TODO Auto-generated method stub
		StudentDetailsBean bean = new StudentDetailsBean();
		BeanUtils.copyProperties(entity, bean);
		return bean;
	}
}
