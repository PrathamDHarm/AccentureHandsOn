package com.acc.lkm.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.acc.lkm.bean.StudentDetailsBean;
import com.acc.lkm.service.StudentDetailsService;

@Controller
@SessionAttributes("studObj")
public class StudentDetailsController {
	
	@Autowired
	private StudentDetailsService service;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}
	
	@RequestMapping(value="/LoadAddDeatils")
	public ModelAndView Loadaddetails() throws Exception{
		ModelAndView mav=new ModelAndView("AddDetails", "studObj",new StudentDetailsBean());
		return mav;
	}
	
	@RequestMapping(value="/Success")
	public ModelAndView addDetails(StudentDetailsBean bean) throws Exception{
		ModelAndView mav=new ModelAndView();
		Integer id=service.addStudentDetails(bean);
		mav.setViewName("Add Details");
		mav.addObject("message","Registration Successfully");
		System.out.println(id);
		return mav;	
	}
}

