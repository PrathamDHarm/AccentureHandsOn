package com.acc.lkm.bean;

import java.util.Date;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

public class StudentDetailsBean {
	private Integer id;
	@NotEmpty(message = "Format s@gmail.com")
	private String username;
	@NotEmpty(message = " Should not be empty")
	private String branch;
	@NotEmpty(message = " Should not be empty")
	private Integer year;
	@NotEmpty(message = " Should not be empty")
	private long reg_number;
	@NotEmpty(message = " Should not be empty")
	private String password;
	@DateTimeFormat(pattern = "dd-mmm-yyyy")
	private Date dob;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public long getReg_number() {
		return reg_number;
	}

	public void setReg_number(long reg_number) {
		this.reg_number = reg_number;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
