package com.acc.lkm.service;

import com.acc.lkm.bean.StudentDetailsBean;

public interface StudentDetailsService {

	public Integer addStudentDetails(StudentDetailsBean bean) throws Exception;
}
