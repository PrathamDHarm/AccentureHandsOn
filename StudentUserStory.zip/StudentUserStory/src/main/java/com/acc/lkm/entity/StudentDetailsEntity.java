package com.acc.lkm.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "StudentDetails")
public class StudentDetailsEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String username;
	private String branch;
	private Integer year;
	private long reg_number;
	private String password;
	private Date dob;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public long getReg_number() {
		return reg_number;
	}

	public void setReg_number(long reg_number) {
		this.reg_number = reg_number;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public StudentDetailsEntity(Integer id, String username, String branch, Integer year, long reg_number,
			String password, Date dob) {
		super();
		this.id = id;
		this.username = username;
		this.branch = branch;
		this.year = year;
		this.reg_number = reg_number;
		this.password = password;
		this.dob = dob;
	}

	public StudentDetailsEntity() {
		super();
	}

}
