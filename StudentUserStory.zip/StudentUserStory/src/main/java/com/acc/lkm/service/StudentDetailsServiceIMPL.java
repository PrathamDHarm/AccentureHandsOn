package com.acc.lkm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acc.lkm.bean.StudentDetailsBean;
import com.acc.lkm.dao.StudentDetailsDAO;
import com.acc.lkm.dao.StudentDetailsWrapper;

@Service
public class StudentDetailsServiceIMPL implements StudentDetailsService {

	
	@Autowired
	private  StudentDetailsWrapper dao;
	
	
	@Override
	public Integer addStudentDetails(StudentDetailsBean bean) throws Exception {
		// TODO Auto-generated method stub
		return dao.addDetails(bean);
	}

	
	
	
}
