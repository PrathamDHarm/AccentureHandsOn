package com.acc.lkm.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.RepositoryDefinition;
import org.springframework.transaction.annotation.Transactional;

import com.acc.lkm.entity.StudentDetailsEntity;


@RepositoryDefinition(idClass = Integer.class, domainClass = StudentDetailsEntity.class)
@Transactional(value = "txManager")
public interface StudentDetailsDAO extends CrudRepository<StudentDetailsEntity, Integer>{
	
	
	
}
